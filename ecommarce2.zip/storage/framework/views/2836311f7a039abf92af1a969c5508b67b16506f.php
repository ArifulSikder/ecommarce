
<?php $__env->startSection('title'); ?>
    ক্যাটেগরি
<?php $__env->stopSection(); ?>


<?php $__env->startSection('category', 'menu-open'); ?>
<?php $__env->startSection('categoryActive', 'active'); ?>

<?php $__env->startSection('maincontant'); ?>
    <div class="row">
        <div class="col-md-7">
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">ক্যাটেগরির তালিকা</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th style="width: 10%">সিরিয়াল</th>
                                
                                <th style="width: 40%">ক্যাটেগরির তথ্য</th>
                                <th style="width: 15%">ক্যাটেগরির আইকন</th>
                                <th style="width: 20%" class="text-center">আকশন</th>
                            </tr>
                        </thead>
                        <?php
                            $serial = ($categories->currentpage() - 1) * $categories->perpage() + 1;
                        ?>
                        <tbody>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($serial++); ?></td>
                                    
                                    <td>
                                        <strong>ক্যাটেগরির নাম :</strong> <?php echo e($category->category_name); ?> <br>
                                        <strong>ক্যাটেগরির স্লাগ :</strong> <?php echo e($category->slug); ?> <br>
                                        <strong>ক্যাটেগরির সাজান :</strong>
                                        <?php echo e($category->category_status == 1 ? 'জনপ্রিয় ক্যাটেগরি' : 'ন্যাভবার'); ?> <br>
                                    </td>
                                    <td><?php echo $category->category_icon; ?></td>
                                    <td class="text-center">
                                        <!-- Large modal -->
                                        <button type="button" class="btn btn-primary btn-sm getData" data-toggle="modal"
                                            data-target="#categoryEdit" data-id="<?php echo e($category->id); ?>"
                                            data-category="<?php echo e($category->category_name); ?>"
                                            data-icon="<?php echo e($category->category_icon); ?>" data-slug="<?php echo e($category->slug); ?>"
                                             data-status="<?php echo e($category->category_status); ?>"
                                            data-slug="<?php echo e($category->slug); ?>"><i class="far fa-edit"></i></button>

                                        <a href="<?php echo e(url('category/' . $category->id)); ?>}}" class="btn btn-danger btn-sm"
                                            id="delete"><i class="far fa-trash-alt"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <div class="d-flex float-right mt-2">
                        <?php echo $categories->links('pagination::bootstrap-5'); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-5">
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">ক্যাটেগরি যোগ করুন</h3>
                </div>
                <div class="card-body">
                    <form role="form" method="POST" action="<?php echo e(route('storeCategory')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="form-group">
                                <label for="category">ক্যাটেগরির নাম</label>
                                <input type="text" class="form-control  <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="category" name="category_name" placeholder="ক্যাটেগরির নাম দিন"
                                    value="<?php echo e(old('category_name')); ?>">
                            </div>
                            <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div class="form-group">
                                <label for="slug">ক্যাটেগরির স্লাগ(English) </label>
                                <input type="text" class="form-control  <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="slug"
                                    name="slug" placeholder="ক্যাটেগরির নাম দিন" value="<?php echo e(old('slug')); ?>">
                            </div>
                            <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div class="form-group">
                                <label for="category_icon">ক্যাটেগরির আইকন</label>
                                <input type="text" class="form-control  <?php $__errorArgs = ['category_icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="categoryIcon" name="category_icon" placeholder="ক্যাটেগরির আইকন দিন"
                                    value="<?php echo e(old('category_icon')); ?>">
                            </div>
                            <?php $__errorArgs = ['category_icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div class="form-group">
                                <label for="category_status">ক্যাটেগরির স্থাপন করুন</label>

                                <select name="category_status"
                                    class="form-control select2  <?php $__errorArgs = ['category_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    style="width: 100%;" data-placeholder="ক্যাটেগরির স্থাপন করুন">
                                    <option selected="selected" value="">ক্যাটেগরির স্থাপন করুন</option>
                                    <option value="1"
                                        <?php echo e(collect(old('category_status'))->contains('1') ? 'selected' : ''); ?>>জনপ্রিয়
                                        ক্যাটেগরিতে যোগ করুন
                                    </option>
                                    <option value="2"
                                        <?php echo e(collect(old('category_status'))->contains('2') ? 'selected' : ''); ?>> ন্যাভবারে
                                        যোগ করুন
                                    </option>
                                </select>
                            </div>
                            <?php $__errorArgs = ['category_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            
                            
                        </div>
                        <!-- /.card-body -->

                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary btn-block">সেভ করুন</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- /.row -->
    
    <div class="modal fade" id="categoryEdit" tabindex="-1" role="dialog" aria-labelledby="editModalCategory"
        aria-hidden="true">
        <div class="modal-dialog  modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-primary">
                    <h5 class="modal-title" id="editModalCategory">ক্যাটেগরি ইডিট করুন</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form role="form" id="EditForm" enctype="multipart/form-data">
                        <input type="hidden" name="id" id="idUpdate" value="">
                        <div class="card-body">
                            <div class="form-group">
                                <label for="category">ক্যাটেগরির নাম</label>
                                <input type="text" class="form-control  <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="category_name" name="category_name" placeholder="ক্যাটেগরির নাম দিন" required
                                    value="">
                            </div>
                            <span class="text-danger" id="nameError"></span>


                            <div class="form-group">
                                <label for="slug">ক্যাটেগরির স্লাগ(English) </label>
                                <input type="text" class="form-control  <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="slugCAt"
                                    name="slug" placeholder="ক্যাটেগরির নাম দিন" value="<?php echo e(old('slug')); ?>" value="">
                            </div>
                            <span class="text-danger" id="slugError"></span>
                            <div class="form-group">
                                <label for="category_icon">ক্যাটেগরির আইকন</label>
                                <input type="text" class="form-control  <?php $__errorArgs = ['category_icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="category_icon" name="category_icon" placeholder="ক্যাটেগরির আইকন দিন" value="">
                            </div>
                            <span class="text-danger" id="iconError"></span>

                            <div class="form-group">
                                <label for="category_status">ক্যাটেগরির স্থাপন করুন</label>

                                <select name="category_status" id="category_status"
                                    class="form-control select2  <?php $__errorArgs = ['category_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    style="width: 100%;" data-placeholder="ক্যাটেগরির স্থাপন করুন">
                                    <option selected="selected">ক্যাটেগরির স্থাপন করুন</option>
                                    <option value="1">জনপ্রিয়
                                        ক্যাটেগরিতে যোগ করুন
                                    </option>
                                    <option value="2"> ন্যাভবারে
                                        যোগ করুন
                                    </option>
                                </select>
                            </div>

                            <span class="text-danger" id="categoryStatusError"></span>
                            
                        </div>
                        <!-- /.card-body -->

                        <div class="card-footer">
                            <button type="submit" id="submitBtn" class="btn btn-primary btn-block">আপডেট করুন</button>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $('.getData').click(function() {
                var id = $(this).data("id");
                var category = $(this).data("category");
                var icon = $(this).data("icon");
                var slug = $(this).data("slug");
                // var thumbnail = $(this).data('thumbnail');
                var status = $(this).data("status");

                $('#idUpdate').val(id);
                $('#category_name').val(category);
                $('#category_icon').val(icon);
                $('#slugCAt').val(slug);
                $('#category_status').val(status).trigger('change');
                // $('.previewHolder').attr('src', thumbnail).css('width', '100px');

            })
        });
    </script>
    <script>
        $(document).ready(function() {
            $("#EditForm").on('submit', function(e) {
                e.preventDefault();
                var formData = new FormData($("#EditForm")[0]);
                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('updateCategory')); ?>",
                    dataType: "json",
                    contentType: false,
                    processData: false,
                    data: formData,
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(response) {
                        if (response.status == 0) {
                            $.each(response, function(index, value) {
                                $("#slugError").text(value.category_slug);
                                $("#nameError").text(value.category_name);
                                $("#iconError").text(value.category_icon);
                            });

                        } else if (response[0].status == 1) {
                            toastr.success(response[0].success);
                            $("#EditForm")[0].reset();
                            location.reload();
                            $('#categoryEdit').modal('hide');
                            // $(".table").load(location.href + " .table");

                        } else if (response[0].status == 2) {
                            toastr.success(response[0].error);
                        }
                    },
                    error: function(error) {
                        if (response[0].category_slug[0]) {
                            $("#slugError").text(response[0].category_slug[0]);
                        } else if (response[0].category_name) {
                            $("#nameError").text(response[0].category_name[0]);
                        } else if (response.category_icon) {
                            $("#iconError").text(response[0].category_icon[0]);
                        }
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.masterLayout.admin-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommarce\resources\views/backend/category/indexCategory.blade.php ENDPATH**/ ?>