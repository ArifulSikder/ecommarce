<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>


    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?php echo e(asset(logo()->main_logo)); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/frontend/vendor/fontawesome-free/css/all.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/frontend/vendor/animate/animate.min.css')); ?>">
    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo e(asset('public/admin/plugins/select2/css/select2.min.css')); ?>">
    <link rel="stylesheet"
        href="<?php echo e(asset('public/admin/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
    <!-- Plugins CSS File -->
    <link rel="stylesheet" type="text/css"
        href="<?php echo e(asset('public/frontend/vendor/magnific-popup/magnific-popup.min.css')); ?>">
    <link rel="stylesheet" type="text/css"
        href="<?php echo e(asset('public/frontend/vendor/owl-carousel/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/frontend/bootstrap/bootstrap.min.css')); ?>">
    <!-- Main CSS File -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/frontend/css/demo3.min.css')); ?>">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('public/admin/plugins/fontawesome-free/css/all.min.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/css/toastr/toastr.min.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('public/frontend/custom/custom.css')); ?>">

</head>

<body class="<?php echo $__env->yieldContent('pageClass'); ?>">

    <?php echo $__env->yieldContent('mainSection'); ?>

    <!-- Plugins JS File -->
    <script src="<?php echo e(asset('public/frontend/vendor/jquery/jquery.min.js')); ?>"></script>
    <!-- jQuery -->
    
    
    
    <script src="<?php echo e(asset('public/frontend/bootstrap/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontend/bootstrap/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontend/vendor/imagesloaded/imagesloaded.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontend/vendor/elevatezoom/jquery.elevatezoom.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontend/vendor/magnific-popup/jquery.magnific-popup.min.js')); ?>"></script>

    <script src="<?php echo e(asset('public/frontend/vendor/owl-carousel/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontend/vendor/sticky/sticky.min.js')); ?>"></script>
    <!-- Main JS File -->
    <script src="<?php echo e(asset('public/frontend/js/main.min.js')); ?>"></script>
    
    <script src="<?php echo e(URL::asset('admin/js/toastr.min.js')); ?>"></script>
    
    <script src="<?php echo e(URL::asset('admin/sweetalert/sweetalert.min.js')); ?>"></script>
    <!-- Select2 -->
    <script src="<?php echo e(asset('public/admin/plugins/select2/js/select2.full.min.js')); ?>"></script>
    <script>
        $(function() {
            //Initialize Select2 Elements
            $('.select2').select2({
                placeholder: function() {
                    $(this).data('placeholder');
                }
            })
        });
    </script>
    <?php if(Session::has('success')): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: "<?php echo e(Session::get('success')); ?>",
                showConfirmButton: false,
                timer: 1500
            })
        </script>
    <?php elseif(!empty(Session::get('error'))): ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: "<?php echo e(Session::get('error')); ?>",
            });
        </script>
    <?php endif; ?>

    <script src="<?php echo e(asset('admin/plugins/spinner/spinner.min.js')); ?>"></script>
    <script>
        $("input[type='number']").inputSpinner();
    </script>
    <?php echo $__env->make('frontend.cart.cartScript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('frontend.include.searchScript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('scriptFontend'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\ecommarce\resources\views/frontend/layout/frontendLayout.blade.php ENDPATH**/ ?>