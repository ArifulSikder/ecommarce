<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo e(url('/')); ?>" class="brand-link text-center">
        <?php echo e(logo()->side_name); ?>

    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="true">
                <li class="nav-item has-treeview <?php echo $__env->yieldContent('dashboard'); ?>">
                    <a href="<?php echo e(route('home')); ?>" class="nav-link <?php echo $__env->yieldContent('dashboardActive'); ?>">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>
                            Dashboard
                        </p>
                    </a>
                </li>
                <li class="nav-item has-treeview <?php echo $__env->yieldContent('category'); ?>">
                    <a href="<?php echo e(route('category')); ?>" class="nav-link  <?php echo $__env->yieldContent('categoryActive'); ?>">
                        <i class="nav-icon fas fa-copy"></i>
                        <p>
                            ক্যাটেগরি
                        </p>
                    </a>
                </li>


                <li class="nav-item has-treeview  <?php echo $__env->yieldContent('banner'); ?>">
                    <a href="#" class="nav-link  <?php echo $__env->yieldContent('bannerActive'); ?>">
                        <i class="nav-icon fas fa-tv"></i>
                        <p>
                            ব্যানার
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('addBanner')); ?>" class="nav-link  <?php echo $__env->yieldContent('addBanner'); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>ব্যানার যোগ করুন</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('banner')); ?>" class="nav-link  <?php echo $__env->yieldContent('banner-list'); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>ব্যানার তালিকা</p>
                            </a>
                        </li>
                    </ul>
                </li>
                
                <li class="nav-item has-treeview  <?php echo $__env->yieldContent('product'); ?>">
                    <a href="#" class="nav-link  <?php echo $__env->yieldContent('productActive'); ?>">
                        <i class="nav-icon fas fa-baby-carriage"></i>
                        <p>
                            প্রোডাক্ট (পন্য)
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('addProduct')); ?>" class="nav-link  <?php echo $__env->yieldContent('addProduct'); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>প্রোডাক্ট যোগ করুন</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('productList')); ?>" class="nav-link  <?php echo $__env->yieldContent('productList'); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>প্রোডাক্ট তালিকা</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('shippingInformation')); ?>" class="nav-link  <?php echo $__env->yieldContent('shippingInformation'); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>পণ্য পৌছানো সংক্রান্ত তথ্য</p>
                            </a>
                        </li>
                    </ul>
                </li>

                
                <li class="nav-item has-treeview  <?php echo $__env->yieldContent('blog'); ?>">
                    <a href="#" class="nav-link  <?php echo $__env->yieldContent('blogActive'); ?>">
                        <i class="nav-icon fas fa-blog"></i>
                        <p>
                            ব্লোগ
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('addBlog')); ?>" class="nav-link  <?php echo $__env->yieldContent('addBlog'); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>ব্লোগ যোগ করুন</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('blogs-list')); ?>" class="nav-link  <?php echo $__env->yieldContent('blogs-list'); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>ব্লোগ তালিকা</p>
                            </a>
                        </li>
                    </ul>
                </li>

                
                <li class="nav-item has-treeview  <?php echo $__env->yieldContent('social'); ?>">
                    <a href="<?php echo e(url('social-links')); ?>" class="nav-link  <?php echo $__env->yieldContent('socialActive'); ?>">
                        <i class="nav-icon fab fa-facebook"></i>
                        <p>
                            সামাজিক মাধ্যম লিংক
                        </p>
                    </a>
                </li>
                
                <li class="nav-item has-treeview  <?php echo $__env->yieldContent('testimonial'); ?>">
                    <a href="#" class="nav-link  <?php echo $__env->yieldContent('testimonialActive'); ?>">
                        <i class="nav-icon far fa-comment-alt"></i>
                        <p>
                            প্রশংসাপত্র
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('indexTestimonial')); ?>" class="nav-link  <?php echo $__env->yieldContent('indexTestimonial'); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>প্রশংসাপত্র তালিকা</p>
                            </a>
                        </li>
                    </ul>
                </li>


                
                <li class="nav-item has-treeview  <?php echo $__env->yieldContent('coupon'); ?>">
                    <a href="#" class="nav-link  <?php echo $__env->yieldContent('activeCoupon'); ?>">
                        <i class="nav-icon fas fa-percent"></i>
                        <p>
                            কুপন
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('coupon-list')); ?>" class="nav-link  <?php echo $__env->yieldContent('coupon-list'); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>কুপন তালিকা</p>
                            </a>
                        </li>
                    </ul>
                </li>


                
                <li class="nav-item has-treeview  <?php echo $__env->yieldContent('location'); ?>">
                    <a href="#" class="nav-link  <?php echo $__env->yieldContent('activeLocation'); ?>">
                        <i class="nav-icon fas fa-location-arrow"></i>
                        <p>
                            লোকেশন
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('division-list')); ?>" class="nav-link  <?php echo $__env->yieldContent('division-list'); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>বিভাগের তালিকা</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('district-list')); ?>" class="nav-link  <?php echo $__env->yieldContent('district-list'); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>জেলার তালিকা</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('thana-list')); ?>" class="nav-link  <?php echo $__env->yieldContent('thana-list'); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>থানা তালিকা</p>
                            </a>
                        </li>
                    </ul>
                </li>

                
                <li class="nav-item has-treeview  <?php echo $__env->yieldContent('brand'); ?>">
                    <a href="#" class="nav-link  <?php echo $__env->yieldContent('activeBrand'); ?>">
                        <i class="nav-icon fas fa-bold"></i>
                        <p>
                            ব্রান্ড
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('brand-list')); ?>" class="nav-link  <?php echo $__env->yieldContent('brand-list'); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>ব্রান্ড তালিকা</p>
                            </a>
                        </li>
                    </ul>
                </li>
                
                <li class="nav-item has-treeview  <?php echo $__env->yieldContent('logo'); ?>">
                    <a href="#" class="nav-link  <?php echo $__env->yieldContent('activeLogo'); ?>">
                        <i class="nav-icon fas fa-signature"></i>
                        <p>
                            লোগো
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('main-logo')); ?>" class="nav-link  <?php echo $__env->yieldContent('main-logo'); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>লোগো তালিকা</p>
                            </a>
                        </li>
                    </ul>
                </li>

                
                <li class="nav-item has-treeview  <?php echo $__env->yieldContent('contact'); ?>">
                    <a href="#" class="nav-link  <?php echo $__env->yieldContent('contactActive'); ?>">
                        <i class="nav-icon far fa-envelope"></i>
                        <p>
                            যোগাযোগের তথ্য
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('contact-us')); ?>" class="nav-link  <?php echo $__env->yieldContent('contact-us'); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>যোগাযোগের তথ্যের তালিকা</p>
                            </a>
                        </li>
                    </ul>
                </li>
                
                <li class="nav-item has-treeview  <?php echo $__env->yieldContent('order'); ?>">
                    <a href="#" class="nav-link  <?php echo $__env->yieldContent('activeOrder'); ?>">
                        <i class="nav-icon fas fa-shopping-basket"></i>
                        <p>
                            সকল অর্ডার
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('pending-order')); ?>" class="nav-link  <?php echo $__env->yieldContent('pending-order'); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>পেনডিং অর্ডার</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('confirm-order')); ?>" class="nav-link  <?php echo $__env->yieldContent('confirm-order'); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>কনফার্ম অর্ডার</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('processing-order')); ?>" class="nav-link  <?php echo $__env->yieldContent('processing-order'); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>প্রক্রিয়াধিন অর্ডার</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('picked-order')); ?>" class="nav-link  <?php echo $__env->yieldContent('picked-order'); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>পিক্ট অর্ডার</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('shipped-order')); ?>" class="nav-link  <?php echo $__env->yieldContent('shipped-order'); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>সিফট অর্ডার</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('deliverd-order')); ?>" class="nav-link  <?php echo $__env->yieldContent('deliverd-order'); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>ডেলিভারি অর্ডার</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('return-order')); ?>" class="nav-link  <?php echo $__env->yieldContent('return-order'); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>রিটার্ন অর্ডার</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route('cancelOrderlist')); ?>" class="nav-link  <?php echo $__env->yieldContent('cancelOrderlist'); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>ক্যান্সেল অর্ডার</p>
                            </a>
                        </li>
                    </ul>
                </li>


                
                <li class="nav-item has-treeview  <?php echo $__env->yieldContent('user'); ?>">
                    <a href=" #" class="nav-link  <?php echo $__env->yieldContent('activeUser'); ?>">
                        <i class=" nav-icon far fa-user-circle"></i>
                        <p>
                            ব্যবহারকারি
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        
                        <li class="nav-item">
                            <a href="<?php echo e(route('userList')); ?>" class="nav-link  <?php echo $__env->yieldContent('userList'); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>ব্যবহারকারির তালিকা</p>
                            </a>
                        </li>
                    </ul>
                </li>
                
                
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
<?php /**PATH C:\xampp\htdocs\ecommarce\resources\views/backend/include/sidebar/sidebar.blade.php ENDPATH**/ ?>