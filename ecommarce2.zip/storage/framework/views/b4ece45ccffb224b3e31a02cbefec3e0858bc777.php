<aside class="col-xl-3 col-lg-4 sidebar sidebar-fixed sticky-sidebar-wrapper home-sidebar">
    <div class="sidebar-overlay">
        <a class="sidebar-close" href="#"><i class="d-icon-times"></i></a>
    </div>
    <a href="#" class="sidebar-toggle"><i class="fas fa-chevron-right"></i></a>
    <div class="sidebar-content">

        <div class="sticky-sidebar">
            <ul class="menu vertical-menu category-menu mb-4">

                <li><a href="#" class="menu-title">জনপ্রিয়
                        ক্যাটাগরি</a>
                </li>
                <?php $__currentLoopData = categoriesPropular(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(url('show-' . $category->slug)); ?>"><?php echo $category->category_icon; ?>

                            <?php echo e($category->category_name); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </ul>
            <?php if(SpecialOffer() != null): ?>
                <a href="<?php echo e(url('_' . SpecialOffer()->product_slug)); ?>">
                    <div class="banner banner-fixed overlay-zoom overlay-dark">
                        <figure>
                            <img src="<?php echo e(asset(SpecialOffer()->product_thumbnail)); ?>" width="280" height="312"
                                alt="banner" style="background-color: #26303c;" />
                        </figure>
                        <div class="banner-content text-center w-100">
                            <h3 class="banner-title ls-m lh-1 text-uppercase text-white font-weight-bold">
                                ছাড় <?php echo e(SpecialOffer()->product_discount); ?>%</h3>
                        </div>
                    </div>
                </a>
            <?php endif; ?>

            <div class="widget widget-blog border-no" data-animation-options="{'delay': '.3s'}">
                <h4 class="widget-title text-capitalize font-weight-bold">সর্বশেষ ব্লোগ</h4>
                <div class="widget-body">
                    <div class="owl-carousel owl-nav-top"
                        data-owl-options="{'items': 1,'loop': false,'nav': true,'dots': false,'margin': 20 }">
                        <?php $__currentLoopData = blogSidebar(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="post overlay-dark overlay-zoom">
                                <figure class="post-media">
                                    <a href="#">
                                        <img src="<?php echo e(asset($blog->blog_thumbnail)); ?>" width="280" height="195"
                                            alt="post" style="background-color: #bcc3ca;" />
                                    </a>
                                </figure>
                                <div class="post-details">
                                    <div class="post-meta">
                                        লেখক <a href="#" class="post-author"> <?php echo e($blog->writer); ?></a>
                                        on <a href="#" class="post-date"><?php echo e(dateFormater($blog->date)); ?></a>
                                    </div>
                                    <h3 class="post-title"><a href="#"><?php echo e($blog->blog_title); ?></a>
                                    </h3>
                                    
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="widget widget-testimonial border-no" data-animation-options="{'delay': '.3s'}">
                <h4 class="widget-title text-capitalize font-weight-bold">প্রশংসাপত্র</h4>
                <div class="widget-body">
                    <div class="owl-carousel owl-nav-top"
                        data-owl-options="{ 'items': 1,'loop': false,'nav': true,'dots': false, 'margin': 20}">

                        <?php $__currentLoopData = testimonialData(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="testimonial">
                                <blockquote class="comment"><?php echo e($testimonial->description); ?></blockquote>
                                <div class="testimonial-info">
                                    <figure class="testimonial-author-thumbnail">
                                        <img src="<?php echo e(asset($testimonial->photo)); ?>" alt="user" width="40"
                                            height="40" />
                                    </figure>
                                    <cite class="font-weight-semi-bold text-capitalize">
                                        <?php echo e($testimonial->name); ?>

                                        <span> <?php echo e($testimonial->designation); ?></span>
                                    </cite>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</aside>
<?php /**PATH C:\xampp\htdocs\ecommarce\resources\views/frontend/include/sidebar.blade.php ENDPATH**/ ?>