

<?php $__env->startSection('title', 'প্রডাক্ট বিবরন'); ?>
<?php $__env->startSection('pageClass', 'products'); ?>


<?php $__env->startSection('mainSection'); ?>
    <div class="page-wrapper">

        <?php echo $__env->make('frontend.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End Header -->
        <main class="main mt-6 single-product">
            <div class="page-content mb-10 pb-9">
                <div class="container">
                    <div class="product product-single row mb-8">
                        <div class="col-md-6">
                            <div class="product-gallery">
                                <div class="product-single-carousel owl-carousel owl-theme owl-nav-inner row cols-1">

                                    <figure class="product-image">
                                        <img src="<?php echo e(asset($product->product_thumbnail)); ?>"
                                            data-zoom-image="<?php echo e(asset($product->product_thumbnail)); ?>"
                                            alt="Blue Pinafore Denim Dress" width="800" height="900"
                                            style="background-color: #f5f5f5;" />
                                    </figure>
                                    <?php $__currentLoopData = $productMultipleImg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <figure class="product-image">
                                            <img src="<?php echo e(asset($image->multiple_image)); ?>"
                                                data-zoom-image="<?php echo e(asset($image->multiple_image)); ?>"
                                                alt="Blue Pinafore Denim Dress" width="800" height="900"
                                                style="background-color: #f5f5f5;" />
                                        </figure>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="product-thumbs-wrap">
                                    <div class="product-thumbs">
                                        <div class="product-thumb active">
                                            <img src="<?php echo e(asset($product->product_thumbnail)); ?>" alt="product thumbnail"
                                                width="137" height="154" style="background-color: #f5f5f5;" />
                                        </div>
                                        <?php $__currentLoopData = $productMultipleImg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="product-thumb">
                                                <img src="<?php echo e(asset($image->multiple_image)); ?>" alt="product thumbnail"
                                                    width="137" height="154" style="background-color: #f5f5f5;" />
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>
                                    <button class="thumb-up disabled"><i class="fas fa-chevron-left"></i></button>
                                    <button class="thumb-down disabled"><i class="fas fa-chevron-right"></i></button>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="product-details  product-gallery-sticky">
                                <div class="product-navigation">
                                    <ul class="breadcrumb breadcrumb-lg">
                                        <li><a href="demo3.html"><i class="d-icon-home"></i></a></li>
                                        <li><a href="#" class="active">পন্য</a></li>
                                        <li>বিস্তারিত</li>
                                    </ul>

                                </div>

                                <h1 class="product-name"><?php echo e($product->product_name); ?></h1>
                                <div class="product-meta">
                                    ক্যাটাগরি:<span class="product-brand"> <?php echo e($product->category->category_name); ?></span>
                                </div>
                                <?php if($product->product_discount > 0): ?>
                                    <div class="product-price">
                                        <ins class="new-price">৳
                                            <?php echo e(banglaNumber($product->product_price - ($product->product_price * $product->product_discount) / 100)); ?>/-</ins><del
                                            class="old-price">৳
                                            <?php echo e(banglaNumber($product->product_price)); ?>/-</del>
                                    </div>
                                <?php else: ?>
                                    <div class="product-price">
                                        <ins class="new-price">৳
                                            <?php echo e(banglaNumber($product->product_price)); ?>/-</ins>
                                    </div>
                                <?php endif; ?>
                                <div class="ratings-container">
                                    
                                </div>
                                <p class="product-short-desc"><?php echo $product->short_description; ?></p>



                                <hr class="product-divider">
                                <input type="hidden" id="product_id" value="<?php echo e($product->id); ?>">
                                <div class="product-form product-qty">
                                    <div class="product-form-group">
                                        <div class="input-group mr-2">
                                            <input type="number" id="quantityProduct" value="1" min="1">
                                        </div>
                                        <?php if($product->product_qty > 0): ?>
                                            <button type="button"
                                                class="shoppingCartBtn AddtoCartFromDetailsPage text-normal ls-normal font-weight-semi-bold"><i
                                                    class="d-icon-bag"></i>কার্টে
                                                যোগ
                                                করুন</button>
                                        <?php else: ?>
                                            <button type="button"
                                                class="shoppingCartBtn bg-danger text-normal ls-normal font-weight-semi-bold"><i
                                                    class="d-icon-bag" disabled></i>স্টকে নেই</button>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <hr class="product-divider mb-3">

                                <div class="product-footer">
                                    <div class="social-links mr-4">
                                        <a href="<?php echo e(socialLinks()->facebook); ?>"
                                            class="social-link social-facebook fab fa-facebook-f"></a>
                                        <a href="<?php echo e(socialLinks()->twitter); ?>"
                                            class="social-link social-twitter fab fa-twitter"></a>
                                        <a href="<?php echo e(socialLinks()->linkdin); ?>"
                                            class="social-link social-linkedin fab fa-linkedin-in"></a>
                                    </div>
                                    <hr class="divider d-lg-show">
                                    <div class="product-action">
                                        
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php if(!empty(productContent($product->id)->long_description)): ?>
                        <div class="tab tab-nav-simple product-tabs mb-5">
                            <ul class="nav nav-tabs justify-content-center" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" href="#product-tab-description">বিস্তারিত</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#product-tab-shipping-returns">পণ্য পৌছানো সংক্রান্ত
                                        তথ্য</a>
                                </li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane active in mb-3" id="product-tab-description">
                                    <div class="row mt-6">
                                        <div class="col-md-6">
                                            <h5 class="description-title mb-4 font-weight-semi-bold ls-m">বৈশিষ্ট্য </h5>
                                            <p class="mb-2">
                                                <?php echo productContent($product->id)->long_description; ?>


                                            </p>

                                        </div>
                                        <div class="col-md-6 pl-md-6 pt-4 pt-md-0">
                                            <?php if(productContent($product->id)->file_type == 'Image'): ?>
                                                <h5 class="description-title font-weight-semi-bold ls-m mb-5">
                                                    ছবিতে বিবরণ
                                                </h5>
                                                <figure class="p-relative d-inline-block mb-2">
                                                    <img src="<?php echo e(asset(productContent($product->id)->content_file)); ?>"
                                                        width="559" height="370" alt="Product" class="w-100"
                                                        style="background-color: #f5f5f5;" />
                                                </figure>
                                            <?php else: ?>
                                                <h5 class="description-title font-weight-semi-bold ls-m mb-5">
                                                    ভিডিও বিবরণ
                                                </h5>

                                                <video width="560" height="315" controls>
                                                    <source
                                                        src="<?php echo e(asset(productContent($product->id)->content_file)); ?>"
                                                        type="video/mp4">
                                                </video>

                                                
                                            <?php endif; ?>
                                            <div class="icon-box-wrap d-flex flex-wrap">
                                                <div class="icon-box icon-box-side icon-border pt-2 pb-2 mb-4 mr-10">
                                                    <div class="icon-box-icon">
                                                        <i class="d-icon-lock"></i>
                                                    </div>
                                                    <div class="icon-box-content">
                                                        <h4 class="icon-box-title lh-1 pt-1 ls-s text-normal">
                                                            <?php echo e(productContent($product->id)->product_warrenty); ?></h4>
                                                        <p>Guarantee with no doubt</p>
                                                    </div>
                                                </div>
                                                <div class="divider d-xl-show mr-10"></div>
                                                <div class="icon-box icon-box-side icon-border pt-2 pb-2 mb-4">
                                                    <div class="icon-box-icon">
                                                        <i class="d-icon-truck"></i>
                                                    </div>
                                                    <?php if(productContent($product->id)->free_shipping): ?>
                                                        <div class="icon-box-content">
                                                            <h4 class="icon-box-title lh-1 pt-1 ls-s text-normal">Free
                                                                shipping
                                                            </h4>
                                                            <p><?php echo e(productContent($product->id)->free_shipping); ?></p>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane " id="product-tab-shipping-returns">
                                    <h6 class="mb-2"><?php echo e($shippingInfo->title); ?></h6>
                                    <p class="mb-0"><?php echo $shippingInfo->description; ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <section class="related-product mt-10">
                        <h2 class="title title-center mb-1 ls-normal">সংশ্লিষ্ট পণ্য</h2>

                        <div class="owl-carousel owl-theme owl-nav-full row cols-2 cols-md-3 cols-lg-4"
                            data-owl-options="{'items': 5, 'nav': false, 'loop': false, 'dots': true, 'margin': 20, 'responsive': { '0': { 'items': 2  }, '768': { 'items': 3 },  '992': { 'items': 4, 'dots': false, 'nav': true }  }   }">
                            <?php $__currentLoopData = catWiseProducts($product->category->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="product text-center">
                                    <figure class="product-media">
                                        <a href="<?php echo e(url('_' . $product->product_slug)); ?>">
                                            <img src="<?php echo e(asset($product->product_thumbnail)); ?>" alt="product"
                                                width="280" height="315">
                                        </a>

                                        <div class="product-action-vertical">
                                            <button class="btn-product-icon ViewProduct" id="<?php echo e($product->id); ?>"
                                                title="Add to cart"><i class="d-icon-bag"></i></button>
                                            
                                        </div>
                                        <div class="product-action">
                                            <a href="<?php echo e(url('_' . $product->product_slug)); ?>" class="btn-product"
                                                title="Quick View">দ্রুত দেখা</a>
                                        </div>
                                    </figure>
                                    <div class="product-details">
                                        <div class="product-cat"><a
                                                href="<?php echo e(url('_' . $product->product_slug)); ?>"><?php echo e($product->category->category_name); ?></a>
                                        </div>
                                        <h3 class="product-name">
                                            <a
                                                href="<?php echo e(url('_' . $product->product_slug)); ?>"><?php echo e($product->product_name); ?></a>
                                        </h3>
                                        <?php if($product->product_discount > 0): ?>
                                            <div class="product-price">
                                                <ins class="new-price">৳
                                                    <?php echo e(banglaNumber($product->product_price - ($product->product_price * $product->product_discount) / 100)); ?>/-</ins><del
                                                    class="old-price">৳
                                                    <?php echo e(banglaNumber($product->product_price)); ?>/-</del>
                                            </div>
                                        <?php else: ?>
                                            <div class="product-price">
                                                <ins class="new-price">৳
                                                    <?php echo e(banglaNumber($product->product_price)); ?>/-</ins>
                                            </div>
                                        <?php endif; ?>
                                        <div class="ratings-container">
                                            
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </section>
                </div>
            </div>
        </main>

        <!-- Modal -->
        <div class="modal fade" id="addCartModal" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="productName">Modal title</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-5">
                                <img id="productThumbnail"
                                    src="<?php echo e(asset('public/frontend')); ?>/images/demos/demo3/logo_.png"
                                    alt="product image">
                            </div>
                            <div class="col-md-7">
                                <ul class="list-group">
                                    <input type="hidden" id="id">
                                    <li class="list-group-item">স্টকে আছে : <strong id="productStock"></strong>
                                    <li class="list-group-item">প্রোডাক্টের কোড : <strong id="productCode"></strong></li>
                                    <li class="list-group-item">প্রোডাক্টের সংখ্যা :
                                        <input type="number" id="quantity" value="1" min="1"></strong>
                                    </li>
                                    
                                    <li class="list-group-item product-price" style="font-size: 13px;">বিক্রয় মুল্য(টাকা)
                                        :
                                        <ins class="new-price">৳ <span id="discunt_price"></span>/-</ins><del
                                            class="old-price">৳
                                            <span id="product_price"></span>/-</del>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary addToCart">কার্টে যোগ করুন</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- End of Main -->
        <?php echo $__env->make('frontend.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- End Footer -->
    </div>
    <?php echo $__env->make('frontend.include.mobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.frontendLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommarce\resources\views/frontend/product/productDetails.blade.php ENDPATH**/ ?>