
<?php $__env->startSection('title'); ?>
    জেলা
<?php $__env->stopSection(); ?>


<?php $__env->startSection('location', 'menu-open'); ?>
<?php $__env->startSection('activeLocation', 'active'); ?>
<?php $__env->startSection('district-list', 'active'); ?>

<?php $__env->startSection('maincontant'); ?>
    <div class="row">
        <div class="col-md-7">
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">জেলার তালিকা</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th style="">সিরিয়াল</th>
                                <th style="">বিভাগের নাম</th>
                                <th style="">জেলার নাম</th>
                                <th style="" class="text-center">আকশন</th>
                            </tr>
                        </thead>
                        <?php
                            $serial = ($districts->currentpage() - 1) * $districts->perpage() + 1;
                        ?>
                        <tbody>
                            <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($serial++); ?></td>
                                    <td><?php echo e($district->division->division_name); ?></td>
                                    <td><?php echo e($district->district_name); ?></td>
                                    <td class="text-center">
                                        <!-- Large modal -->
                                        <button type="button" class="btn btn-primary btn-sm getData" data-toggle="modal"
                                            data-target="#editDivision" data-id="<?php echo e($district->id); ?>"
                                            data-division="<?php echo e($district->division_name); ?>"><i
                                                class="far fa-edit"></i></button>

                                        <a href="<?php echo e(url('district-delete/' . $district->id)); ?>"
                                            class="btn btn-danger btn-sm" id="delete"><i class="far fa-trash-alt"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="d-flex float-right mt-2">
                        <?php echo $districts->links('pagination::bootstrap-5'); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-5">
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">জেলা যোগ করুন</h3>
                </div>
                <div class="card-body">
                    <form role="form" method="POST" action="<?php echo e(route('storeDistrict')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="form-group">
                                <label for="division_id">বিভাগের নাম</label>
                                <select name="division_id"
                                    class="form-control select2  <?php $__errorArgs = ['division_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    style="width: 100%;" data-placeholder='বিভাগের নাম বাছাই ক্রুন'>
                                    <option value=""></option>
                                    <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($division->id); ?>"
                                            <?php echo e(collect(old('division_id'))->contains($division->id) ? 'selected' : ''); ?>>
                                            <?php echo e($division->division_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['division_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="district_name">জেলার নাম</label>
                                <input type="text" class="form-control  <?php $__errorArgs = ['district_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="district_name" placeholder="জেলার নাম দিন" id="district_name"
                                    value="<?php echo e(old('district_name')); ?>">
                            </div>
                            <?php $__errorArgs = ['district_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!-- /.card-body -->

                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary btn-block">সেভ করুন</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- /.row -->

    
    <div class="modal fade" id="editDivision" tabindex="-1" role="dialog" aria-labelledby="editDivisionItem"
        aria-hidden="true">
        <div class="modal-dialog  modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-primary">
                    <h5 class="modal-title" id="editDivisionItem">বিভাগ ইডিট করুন</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form role="form" id="divisionFrom">
                        <input type="hidden" id="id_up" name="id">
                        <div class="card-body">
                            <div class="form-group">
                                <label for="division_name">বিভাগের নাম</label>
                                <input type="text" class="form-control" name="division_name" placeholder="বিভাগের নাম দিন"
                                    id="division_name_up">
                            </div>
                            <span class="text-danger" id="divisionError"></span>
                        </div>
                        <!-- /.card-body -->

                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary btn-block">আপডেট করুন</button>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $('.getData').click(function() {
                var id = $(this).data("id");
                var division = $(this).data("division");

                $('#id_up').val(id);
                $('#division_name_up').val(division);

            });


            $("#divisionFrom").on('submit', function(e) {
                e.preventDefault();
                var formData = new FormData($("#divisionFrom")[0]);
                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('division-update')); ?>",
                    dataType: "json",
                    contentType: false,
                    processData: false,
                    data: formData,
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(response) {
                        if (response.status == 0) {
                            $.each(response, function(index, value) {
                                $("#divisionError").text(value.division_name);
                            });

                        } else if (response.status == 1) {
                            toastr.success(response.success);
                            $('#editDivision').modal('hide');
                            location.reload();
                            $("#EditForm")[0].reset();
                            // $(".table").load(location.href + " .table");

                        } else if (response.status == 2) {
                            toastr.success(response.error);
                        }
                    },
                    error: function(error) {
                        $("#divisionError").text(error.category_slug);
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.masterLayout.admin-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommarce\resources\views/backend/location/district/districtIndex.blade.php ENDPATH**/ ?>