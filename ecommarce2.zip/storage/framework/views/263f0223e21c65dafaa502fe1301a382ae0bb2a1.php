<section class="mb-3">
    <h4 class="widget-title font-weight-bold">সর্বশেষ পন্য</h4>
    <div class="row">
        <div class="col-md-4 col-sm-6 mb-4">

            <div class="widget widget-products appear-animate"
                data-animation-options="{'name': 'fadeInLeftShorter', 'delay': '.5s'}">
                <div class="products-col">
                    <?php $__currentLoopData = latestProduct()->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="product product-list-sm">
                            <figure class="product-media">
                                <a href="<?php echo e(url('_' . $product->product_slug)); ?>">
                                    <img src="<?php echo e(asset($product->product_thumbnail)); ?>" alt="product" width="100"
                                        height="100" style="background-color: #f5f5f5;" />
                                </a>
                            </figure>
                            <div class="product-details">
                                <h3 class="product-name">
                                    <a
                                        href="<?php echo e(url('_' . $product->product_slug)); ?>"><?php echo e($product->product_name); ?></a>
                                </h3>
                                <?php if($product->product_discount > 0): ?>
                                    <div class="product-price">
                                        <ins class="new-price">৳
                                            <?php echo e(banglaNumber($product->product_price - ($product->product_price * $product->product_discount) / 100)); ?>/-</ins><del
                                            class="old-price">৳
                                            <?php echo e(banglaNumber($product->product_price)); ?>/-</del>
                                    </div>
                                <?php else: ?>
                                    <div class="product-price">
                                        <ins class="new-price">৳
                                            <?php echo e(banglaNumber($product->product_price)); ?>/-</ins>
                                    </div>
                                <?php endif; ?>
                                <div class="ratings-container">
                                    
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 mb-4 ">
            <div class="widget widget-products appear-animate"
                data-animation-options="{'name': 'fadeIn','delay': '.3s'}">
                <div class="products-col">
                    <?php $__currentLoopData = latestProduct()->skip(3)->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="product product-list-sm">
                            <figure class="product-media">
                                <a href="<?php echo e(url('_' . $product->product_slug)); ?>">
                                    <img src="<?php echo e(asset($product->product_thumbnail)); ?>" alt="product" width="100"
                                        height="100" style="background-color: #f5f5f5;" />
                                </a>
                            </figure>
                            <div class="product-details">
                                <h3 class="product-name">
                                    <a
                                        href="<?php echo e(url('_' . $product->product_slug)); ?>"><?php echo e($product->product_name); ?></a>
                                </h3>
                                <?php if($product->product_discount > 0): ?>
                                    <div class="product-price">
                                        <ins class="new-price">৳
                                            <?php echo e(banglaNumber($product->product_price - ($product->product_price * $product->product_discount) / 100)); ?>/-</ins><del
                                            class="old-price">৳
                                            <?php echo e(banglaNumber($product->product_price)); ?>/-</del>
                                    </div>
                                <?php else: ?>
                                    <div class="product-price">
                                        <ins class="new-price">৳
                                            <?php echo e(banglaNumber($product->product_price)); ?>/-</ins>
                                    </div>
                                <?php endif; ?>
                                <div class="ratings-container">
                                    
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 mb-4">
            <div class="widget widget-products appear-animate"
                data-animation-options="{'name': 'fadeInRightShorter','delay': '.5s'}">
                <div class="products-col">
                    <?php $__currentLoopData = latestProduct()->skip(6)->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="product product-list-sm">
                            <figure class="product-media">
                                <a href="<?php echo e(url('_' . $product->product_slug)); ?>">
                                    <img src="<?php echo e(asset($product->product_thumbnail)); ?>" alt="product" width="100"
                                        height="100" style="background-color: #f5f5f5;" />
                                </a>
                            </figure>
                            <div class="product-details">
                                <h3 class="product-name">
                                    <a
                                        href="<?php echo e(url('_' . $product->product_slug)); ?>"><?php echo e($product->product_name); ?></a>
                                </h3>
                                <?php if($product->product_discount > 0): ?>
                                    <div class="product-price">
                                        <ins class="new-price">৳
                                            <?php echo e(banglaNumber($product->product_price - ($product->product_price * $product->product_discount) / 100)); ?>/-</ins><del
                                            class="old-price">৳
                                            <?php echo e(banglaNumber($product->product_price)); ?>/-</del>
                                    </div>
                                <?php else: ?>
                                    <div class="product-price">
                                        <ins class="new-price">৳
                                            <?php echo e(banglaNumber($product->product_price)); ?>/-</ins>
                                    </div>
                                <?php endif; ?>
                                <div class="ratings-container">
                                    
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\ecommarce\resources\views/frontend/include/latestProduct.blade.php ENDPATH**/ ?>