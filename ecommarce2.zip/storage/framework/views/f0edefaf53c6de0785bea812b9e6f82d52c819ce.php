
<?php $__env->startSection('title'); ?>
    ব্রান্ড
<?php $__env->stopSection(); ?>


<?php $__env->startSection('brand', 'menu-open'); ?>
<?php $__env->startSection('activeBrand', 'active'); ?>
<?php $__env->startSection('brand-list', 'active'); ?>

<?php $__env->startSection('maincontant'); ?>
    <div class="row">
        <div class="col-md-7">
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">ব্রান্ডের তালিকা</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th style="width: 10%">সিরিয়াল</th>
                                <th style="width: 20%">ব্রান্ডের ছবি</th>
                                <th style="width: 20%">ব্রান্ডের স্টেটাস</th>
                                <th style="width: 20%" class="text-center">আকশন</th>
                            </tr>
                        </thead>
                        <?php
                            $serial = ($brands->currentpage() - 1) * $brands->perpage() + 1;
                        ?>
                        <tbody>
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($serial++); ?></td>
                                    <td><img width="150" src="<?php echo e(asset($brand->brand_image)); ?>" alt="brand logo"></td>
                                    <td>
                                        <span class="badge badge-<?php echo e($brand->status == 1 ? 'success' : 'danger'); ?>">
                                            <?php echo e($brand->status == 1 ? 'Active' : 'Inactive'); ?>

                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <!-- Large modal -->
                                        <button type="button" class="btn btn-primary btn-sm getCouponData"
                                            data-toggle="modal" data-target="#brandEdit<?php echo e($brand->id); ?>"><i
                                                class="far fa-edit"></i></button>

                                        <a href="<?php echo e(url('delete-brand/' . $brand->id)); ?>" class="btn btn-danger btn-sm"
                                            id="delete"><i class="far fa-trash-alt"></i></a>
                                    </td>
                                </tr>
                                <!-- modal edit -->
                                <div class="modal fade" id="brandEdit<?php echo e($brand->id); ?>" tabindex="-1" role="dialog"
                                    aria-labelledby="editBrandModal" aria-hidden="true">
                                    <div class="modal-dialog  modal-lg" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header bg-primary">
                                                <h5 class="modal-title" id="editBrandModal">ব্রান্ড ইডিট করুন</h5>
                                                <button type="button" class="close" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="card-body">
                                                    <form role="form" method="POST" action="<?php echo e(route('updateBrand')); ?>"
                                                        enctype="multipart/form-data">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="id" value="<?php echo e($brand->id); ?>">
                                                        <div class="card-body">
                                                            <div class="form-group">
                                                                <label for="brand_image">ব্রান্ডের ছবি বাছাই</label>
                                                                <input type="file"
                                                                    class="form-control  <?php $__errorArgs = ['brand_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                    id="photoUpload" name="brand_image"
                                                                    placeholder="ব্রান্ডের ছবি দিন">
                                                            </div>
                                                            <?php $__errorArgs = ['brand_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            <img id="previewHolder" height="100px"
                                                                src="<?php echo e(asset($brand->brand_image)); ?>"
                                                                alt="brand_image preview">
                                                        </div>
                                                        <!-- /.card-body -->

                                                        <div class="card-footer">
                                                            <button type="submit" class="btn btn-primary btn-block">সেভ
                                                                করুন</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <div class="d-flex float-right mt-2">
                        <?php echo $brands->links('pagination::bootstrap-5'); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-5">
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">ব্রান্ডের যোগ করুন</h3>
                </div>
                <div class="card-body">
                    <form role="form" method="POST" action="<?php echo e(route('storeBrand')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="form-group">
                                <label for="brand_image">ব্রান্ডের ছবি বাছাই</label>
                                <input type="file" class="form-control  <?php $__errorArgs = ['brand_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="photoUpload" name="brand_image" placeholder="ব্রান্ডের ছবি দিন"
                                    value="<?php echo e(old('brand_image')); ?>">
                            </div>
                            <?php $__errorArgs = ['brand_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <img id="previewHolder" src="" alt="">
                        </div>
                        <!-- /.card-body -->

                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary btn-block">সেভ করুন</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.masterLayout.admin-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommarce\resources\views/backend/brand/indexBrand.blade.php ENDPATH**/ ?>