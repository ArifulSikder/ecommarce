
<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>


<?php $__env->startSection('dashboardActive', 'active'); ?>

<?php $__env->startSection('maincontant'); ?>
    <?php
    $color = [
        1 => 'bg-primary',
        2 => 'bg-success',
        3 => 'bg-info',
        4 => 'bg-secondary',
        5 => 'bg-dark',
        6 => 'bg-warning',
    ];
    $color2 = [
        1 => 'bg-danger',
    ];
    $serial = 1;
    ?>

    <div class="card">
        <div class="card-body">
            <!-- Small boxes (Stat box) -->
            <h4>ভ্রমনকারির তথ্য</h4>
            <div class="row">
                <div class="col-lg-3 col-6 text-white">
                    <!-- small box -->
                    <div
                        class="small-box <?php echo e($serial < 7 ? $color[$serial++] : $color2[($serial = $serial - ($serial - 1))]); ?>">
                        <div class="inner">
                            <h4>মোট ভ্রমনকারির সংখ্যা </h4>
                            <h5><?php echo e($allVisitor); ?> জন</h5>
                        </div>
                        <div class="icon">
                            
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-6 text-white">
                    <!-- small box -->
                    <div
                        class="small-box <?php echo e($serial < 7 ? $color[$serial++] : $color2[($serial = $serial - ($serial - 1))]); ?>">
                        <div class="inner">
                            <h4>মোট এই মাসের ভ্রমন </h4>
                            <h5><?php echo e(banglaNumber($currentMonthVisitor)); ?> জন</h5>
                        </div>
                        <div class="icon">
                            
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6 text-white">
                    <!-- small box -->
                    <div
                        class="small-box <?php echo e($serial < 7 ? $color[$serial++] : $color2[($serial = $serial - ($serial - 1))]); ?>">
                        <div class="inner">
                            <h4>মোট আজকের ভ্রমন </h4>
                            <h5><?php echo e(banglaNumber($todaysVisitor)); ?> জন</h5>
                        </div>
                        <div class="icon">
                            
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6 text-white">
                    <!-- small box -->
                    <div
                        class="small-box <?php echo e($serial < 7 ? $color[$serial++] : $color2[($serial = $serial - ($serial - 1))]); ?>">
                        <div class="inner">
                            <h4>সর্বশেষ ভ্রমনের সময় </h4>
                            <h5><?php echo e(banglaNumber(timeFormater($lastVisitTime->date))); ?></h5>
                        </div>
                        <div class="icon">
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <!-- Small boxes (Stat box) -->
            <h4>ক্যাটাগরির তথ্য</h4>
            <div class="row">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-6 text-white">
                        <!-- small box -->
                        <div class="small-box <?php echo e($serial < 7 ? $color[$serial++] : $color2[($serial = 1)]); ?>">
                            <div class="inner">
                                <h4><?php echo e($category->category_name); ?></h4>
                                <h5>মোট ভ্রমন করেছেঃ <?php echo e(banglaNumber(categoryVisitedTimes($category->id))); ?> বার</h5>
                            </div>
                            <div class="icon">
                                
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <!-- Small boxes (Stat box) -->
            <h4>প্রোডাক্টের তথ্য</h4>
            <div class="row">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-6 text-white">
                        <!-- small box -->
                        
                        <div class="small-box <?php echo e($serial < 7 ? $color[$serial++] : $color2[($serial = 1)]); ?>">
                            <div class="inner">
                                <h4><?php echo e($product->product_name); ?></h4>
                                <h5>মোট ভ্রমন করেছেঃ <?php echo e(banglaNumber(productVisitedTimes($product->id))); ?> বার</h5>
                            </div>
                            <div class="icon">
                                
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.masterLayout.admin-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommarce\resources\views/backend/dashboard/index.blade.php ENDPATH**/ ?>