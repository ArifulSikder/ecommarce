  <!-- Sticky Footer -->

  <div class="sticky-footer sticky-content fix-bottom">

      <a href="<?php echo e(url('/')); ?>" class="sticky-link active">
          <i class="d-icon-home"></i>
          <span>Home</span>
      </a>
      
      

      <div class="header-search hs-toggle dir-up">
          <a href="#" class="search-toggle sticky-link">
              <i class="d-icon-search"></i>
              <span>Search</span>
          </a>
          <form action="#" class="input-wrapper">
              <input type="text" class="form-control" name="search" id="liveSearchMobileFooter"
                  placeholder="Search your keyword..." required />
              <button class="btn btn-search" type="button" id="searchButton">
                  <i class="d-icon-search"></i>
              </button>

          </form>

      </div>
  </div>

  <!-- Scroll Top -->
  <a id="scroll-top" href="#top" title="Top" role="button" class="scroll-top"><i class="d-icon-arrow-up"></i></a>

  <!-- MobileMenu -->
  <div class="mobile-menu-wrapper">
      <div class="mobile-menu-overlay">
      </div>
      <!-- End of Overlay -->
      <a class="mobile-menu-close" href="#"><i class="d-icon-times"></i></a>
      <!-- End of CloseButton -->
      <div class="mobile-menu-container scrollable">
          <form action="#" class="input-wrapper">
              <input type="text" class="form-control" id="searchKeyWordMobile" name="search"
                  placeholder="Search your keyword..." required />
              <button class="btn btn-search" type="submit">
                  <i class="d-icon-search"></i>
              </button>
          </form>

          <div class="searchAutoComplete">
              
          </div>
          <!-- End of Search Form -->
          <ul class="mobile-menu mmenu-anim">
              <li>
                  <a href="<?php echo e(url('/')); ?>"><i class="fas fa-home"></i>Home</a>
              </li>
              <?php $__currentLoopData = categoriesNav(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><a href="<?php echo e(url('show-' . $category->slug)); ?>"><?php echo $category->category_icon; ?>

                          <?php echo e($category->category_name); ?></a></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
          <!-- End of MobileMenu -->
      </div>
  </div>


  
  <div class="modal fade searchDataModal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel"
      aria-hidden="true">
      <div class="modal-dialog modal-sm">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
          </button>
          <div class="modal-content">
              <div id="searchdata">

              </div>
          </div>
      </div>
  </div>
<?php /**PATH C:\xampp\htdocs\ecommarce\resources\views/frontend/include/mobile.blade.php ENDPATH**/ ?>